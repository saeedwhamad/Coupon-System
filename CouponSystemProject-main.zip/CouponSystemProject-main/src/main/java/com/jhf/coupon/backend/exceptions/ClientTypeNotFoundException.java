package com.jhf.coupon.backend.exceptions;

public class ClientTypeNotFoundException extends Exception {
	public ClientTypeNotFoundException(String message) {
		super(message);
	}
}
