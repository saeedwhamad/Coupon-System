package com.jhf.coupon.backend.exceptions.company;

public class CantUpdateCompanyException extends Exception {
	public CantUpdateCompanyException(String message) {
		super(message);
	}
}
