package com.jhf.coupon;

public class Program {
	public static void main(String[] args) {
		try {
			Test.testAll();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
