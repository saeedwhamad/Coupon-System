package com.jhf.coupon.backend.exceptions.coupon;

public class CouponAlreadyExistsForCompanyException extends Exception {
	public CouponAlreadyExistsForCompanyException(String message) {
		super(message);
	}
}
