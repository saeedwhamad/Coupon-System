package com.jhf.coupon.backend.exceptions.company;

public class CompanyAlreadyExistsException extends Exception {
	public CompanyAlreadyExistsException(String message) {
		super(message);
	}
}
