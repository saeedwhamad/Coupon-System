package com.jhf.coupon.backend.exceptions;

public class CategoryNotFoundException extends Exception {
	public CategoryNotFoundException(String message) {
		super(message);
	}
}
