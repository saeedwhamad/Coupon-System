package com.jhf.coupon.backend.exceptions.customer;

public class CantUpdateCustomerException extends Exception {
	public CantUpdateCustomerException(String message) {
		super(message);
	}
}
