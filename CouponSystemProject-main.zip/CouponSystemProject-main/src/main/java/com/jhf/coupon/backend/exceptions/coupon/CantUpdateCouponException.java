package com.jhf.coupon.backend.exceptions.coupon;

public class CantUpdateCouponException extends Exception {
	public CantUpdateCouponException(String message) {
		super(message);
	}
}
