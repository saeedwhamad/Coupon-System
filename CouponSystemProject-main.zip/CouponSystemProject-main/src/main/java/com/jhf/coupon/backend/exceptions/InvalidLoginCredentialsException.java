package com.jhf.coupon.backend.exceptions;

public class InvalidLoginCredentialsException extends Exception {
	public InvalidLoginCredentialsException(String message) {
		super(message);
	}
}
