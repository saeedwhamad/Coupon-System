# CouponSystemProject
JHF FullStack Bootcamp Project

to Test the Project;
- Import couponSystemSchema in resources

- Add MySQL user "projectUser" with root all permissions  (OR) change MySQL username, & password (found in ConnectionPool):
- line:11     private static final String USER = "projectUser";
- line:12     private static final String PASSWORD = "projectUser";

- run Program.

